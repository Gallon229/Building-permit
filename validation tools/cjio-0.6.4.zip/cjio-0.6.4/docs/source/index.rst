.. cjio documentation master file, created by
   sphinx-quickstart on Thu May  2 15:57:04 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

================================
Welcome to cjio's documentation!
================================

.. toctree::
   :maxdepth: 2

   includeme
   tutorials
   modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
