cjio package
============

cjio.cityjson module
--------------------

.. automodule:: cjio.cityjson
   :members:
   :undoc-members:
   :show-inheritance:

cjio.cjio module
----------------

.. automodule:: cjio.cjio
   :members:
   :undoc-members:
   :show-inheritance:

cjio.convert module
-------------------

.. automodule:: cjio.convert
   :members:
   :undoc-members:
   :show-inheritance:

cjio.errors module
------------------

.. automodule:: cjio.errors
   :members:
   :undoc-members:
   :show-inheritance:

cjio.geom\_help module
----------------------

.. automodule:: cjio.geom_help
   :members:
   :undoc-members:
   :show-inheritance:

cjio.models module
------------------

.. automodule:: cjio.models
   :members:
   :undoc-members:
   :show-inheritance:

cjio.remove\_textures module
----------------------------

.. automodule:: cjio.remove_textures
   :members:
   :undoc-members:
   :show-inheritance:

cjio.subset module
------------------

.. automodule:: cjio.subset
   :members:
   :undoc-members:
   :show-inheritance:

cjio.utils module
-----------------

.. automodule:: cjio.utils
   :members:
   :undoc-members:
   :show-inheritance:

cjio.validation module
----------------------

.. automodule:: cjio.validation
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: cjio
   :members:
   :undoc-members:
   :show-inheritance:
