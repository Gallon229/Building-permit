docker run --rm --network=host --name=cesium -v $(pwd):/opt/cesium/cjio cesium
